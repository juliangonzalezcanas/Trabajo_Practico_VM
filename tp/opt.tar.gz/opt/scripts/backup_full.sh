#!/bin/bash

if [[ $1 == "-help" ]];then
echo "El script usa 2 argumentos. El primero es el origen y el segundo es el destino"
exit 0
elif [[ $# -ne 2 ]];then
echo "Se requieren 2 argumenos"
exit 1
fi

if [[ ! -d "$1" ]];then
echo "El directorio de origen no existe"
exit 1
elif [[ ! -d "$2" ]];then
echo "El directorio de destino no existe"
exit 1
fi

FECHA=$(date +%Y%m%d)

BACKUP=$(basename "$1")_bkp_$FECHA.tar.gz

tar -czf "$2/$BACKUP" -c "$1"

if [[ -f "$2/$BACKUP" ]];then
echo "Se guardo correctamente."
exit 0
else
echo "Hubo un error al crear el backup"
exit 1
fi
